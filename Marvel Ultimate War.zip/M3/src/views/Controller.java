package views;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.tools.DocumentationTool.Location;

import engine.Game;
import engine.Player;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.DamagingAbility;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;

public class Controller implements ActionListener,KeyListener {
	
	private StageOne firstStage;
	private StageTwo secondStage;
	private StageThree thirdStage;
	
	private Game model;
	
	public Controller() throws IOException {
		
		firstStage = new StageOne();
		firstStage.getStart().addActionListener(this);
		generateSound("sound-effects/game-starts.wav");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if( e.getSource() == firstStage.getStart() ){
				if(firstStage.getFirstName().getText().equals("") || firstStage.getSecondName().getText().equals("")) {
					JOptionPane.showMessageDialog(firstStage, "Please enter both players names ","Error",JOptionPane.ERROR_MESSAGE);
				}
				else {
					firstStage.setVisible(false);
					Player firstPlayer = new Player(firstStage.getFirstName().getText());
					Player secondPlayer = new Player(firstStage.getSecondName().getText());
					model = new Game(firstPlayer, secondPlayer);
					
					ArrayList<Champion> championsList= model.getAvailableChampions();

					secondStage = new StageTwo(firstPlayer, secondPlayer, championsList);
					secondStage.getStartBattle().addActionListener(this);
					//generateSound("sound-effects/game-starts.wav");
				}
			}
			else if(e.getSource() == secondStage.getStartBattle()) {
				if(model.getFirstPlayer().getLeader()==null || model.getSecondPlayer().getLeader()==null)
					JOptionPane.showMessageDialog(firstStage, "Please choose the leader of each player","Error",JOptionPane.ERROR_MESSAGE);
				else if(model.getFirstPlayer().getTeam().size()!=3 || model.getSecondPlayer().getTeam().size()!=3)
					JOptionPane.showMessageDialog(firstStage, "Each player has to choose 3 champions","Error",JOptionPane.ERROR_MESSAGE);
				else {
					secondStage.setVisible(false);
					model.placeChampions();
					model.prepareChampionTurns();
					thirdStage = new StageThree(model);
					
					thirdStage.greenBackground(model.getCurrentChampion());
					thirdStage.changeTurnArea();
					
					thirdStage.getEndTurnButton().addActionListener(this);
					thirdStage.getUpAttack().addActionListener(this);
					thirdStage.getDownAttack().addActionListener(this);
					thirdStage.getLeftAttack().addActionListener(this);
					thirdStage.getRightAttack().addActionListener(this);
					thirdStage.getUseLA().addActionListener(this);
					
					thirdStage.getHealingBox().addActionListener(this);
					thirdStage.getDamagingBox().addActionListener(this);
					thirdStage.getCrowdBox().addActionListener(this);
					thirdStage.getDirectionBox().addActionListener(this);
					thirdStage.getChooseX().addActionListener(this);
					thirdStage.getChooseY().addActionListener(this);

					model.setListener(thirdStage);
					
					JButton[][] buttonsList = thirdStage.getLocationsOfBoard();
					
					for(int i=0 ; i<5 ; i++) {
						for(int j=0 ; j<5 ; j++) 
							buttonsList[i][j].addKeyListener(this);
					}
					
					thirdStage.changeAbilityBoxes();

				}
				
			}
			else if(e.getSource() == thirdStage.getEndTurnButton()) {
				model.endTurn();
				generateSound("sound-effects/well-done.wav");
			}
			
			else if(e.getSource() == thirdStage.getUpAttack()) {
				model.attack(Direction.UP);
			}
			else if(e.getSource() == thirdStage.getDownAttack()) {
				model.attack(Direction.DOWN);

			}
			else if(e.getSource() == thirdStage.getLeftAttack()) {
				model.attack(Direction.LEFT);

			}
			else if(e.getSource() == thirdStage.getRightAttack()) {
				model.attack(Direction.RIGHT);

			}
			else if(e.getSource() == thirdStage.getUseLA()) {
				model.useLeaderAbility();
				generateSound("sound-effects/ULA3.wav");
			}
			
			else if(e.getSource() == thirdStage.getHealingBox() || e.getSource()==thirdStage.getDamagingBox() || e.getSource()==thirdStage.getCrowdBox()) {
				JComboBox<AreaOfEffect> box;
				
				if(e.getSource()==thirdStage.getHealingBox())
					box = thirdStage.getHealingBox();
				else if(e.getSource() == thirdStage.getDamagingBox())
					box = thirdStage.getDamagingBox();
				else
					box = thirdStage.getCrowdBox();
				
				AreaOfEffect areaOfEffect = (AreaOfEffect) box.getSelectedItem();
				Ability castedAbility = null;
				
				for (Ability a : model.getCurrentChampion().getAbilities()) {
					if(a.getCastArea() == areaOfEffect)
						castedAbility = a ;
				}
				
				if(areaOfEffect == AreaOfEffect.SELFTARGET || areaOfEffect == AreaOfEffect.SURROUND || areaOfEffect == AreaOfEffect.TEAMTARGET) {
					model.castAbility(castedAbility);
					generateSound("sound-effects/outstanding.wav");
					if(castedAbility instanceof DamagingAbility)
						generateSound("sound-effects/damage-cast.wav");
				}
				
				else if(areaOfEffect == AreaOfEffect.DIRECTIONAL) {
					
					Direction direction = (Direction) thirdStage.getDirectionBox().getSelectedItem();
					
					if(direction == null) {
						generateSound("sound-effects/buzzer.wav");
						JOptionPane.showMessageDialog(thirdStage, "Please select direction before casting the ability","Error",JOptionPane.ERROR_MESSAGE);
						return;
					}
					if(direction == Direction.UP)
						direction = Direction.DOWN;
					else if(direction == Direction.DOWN)
						direction = Direction.UP;
					
					model.castAbility(castedAbility, direction);
					generateSound("sound-effects/outstanding.wav");
					if(castedAbility instanceof DamagingAbility)
						generateSound("sound-effects/damage-cast.wav");
					
				}
				else if(areaOfEffect == AreaOfEffect.SINGLETARGET) {
					Integer x = (Integer) thirdStage.getChooseX().getSelectedItem();
					Integer y = (Integer) thirdStage.getChooseY().getSelectedItem();
					if(x == null || y == null) {
						generateSound("sound-effects/buzzer.wav");
						JOptionPane.showMessageDialog(thirdStage, "Please select target coordinates before casting the ability","Error",JOptionPane.ERROR_MESSAGE);
						return;
					}
					model.castAbility(castedAbility, 4-x, y);
					generateSound("sound-effects/outstanding.wav");
					if(castedAbility instanceof DamagingAbility)
						generateSound("sound-effects/damage-cast.wav");
						
				}
				
			}
			

			
		}
		catch (IOException | ChampionDisarmedException | NotEnoughResourcesException | LeaderAbilityAlreadyUsedException | LeaderNotCurrentException | CloneNotSupportedException | InvalidTargetException | AbilityUseException exception) {
			generateSound("sound-effects/buzzer.wav");
			JOptionPane.showMessageDialog(firstStage, exception.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
		}
		
		finally {
			Player player = model.checkGameOver();
			if(player != null && e.getSource() != firstStage.getStart()) {
				generateSound("sound-effects/victory.wav");
				JOptionPane.showMessageDialog(firstStage, player.getName()+" wins the battle","Game Over",JOptionPane.ERROR_MESSAGE);
				thirdStage.dispose();
				secondStage.dispose();
				firstStage.dispose();
			}
		}
		
	}
	
	public void generateSound(String filePath) {
		try {
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(filePath).getAbsoluteFile());
			Clip clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			clip.start();
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws IOException {
		new Controller();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		try {
			if(e.getKeyCode() == 37){//left
				model.move(Direction.LEFT);
			}
			else if(e.getKeyCode() == 40){//up
				model.move(Direction.UP);
			}
			else if(e.getKeyCode() == 39){//right
				model.move(Direction.RIGHT);
			}
			else if(e.getKeyCode() == 38){ //down
				model.move(Direction.DOWN);
			}
		}
		catch (UnallowedMovementException | NotEnoughResourcesException | IOException  exception) {
			generateSound("sound-effects/buzzer.wav");
			JOptionPane.showMessageDialog(firstStage, exception.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		
	}

	


}
